#!/usr/bin/perl

if ($ENV{'REQUEST_METHOD'} eq "POST"){$buffer = $ENV{QUERY_STRING};}
@pairs = split(/&/,$buffer);
foreach (@pairs) {
	($name, $value) = split(/=/, $_);
	$value =~ tr/+/ /;
	$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
	$value =~ s/</&lt;/g;
	$value =~ s/>/&gt;/g;
	$value =~ s/\r//g;
	$value =~ s/\n//g;
	$FORM{$name} = $value;
}

open (IN,"data.txt");
@DATA = <IN>;
close (IN);

#ヘッダの出力のサンプル
print "Content-type: text/html\n\n";

#HTMLの出力のサンプル

print <<EOL; 
<html lang="ja">
<head>
<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link type='text/css' rel='stylesheet' href='base.css' />
</head><body>$FORM{'kanso'}
<form action="data.cgi" method="POST">
<textarea name="kanso" rows="10" cols="30">@DATA </textarea><br>
<input type="submit" value="送信">
</form>
</body>
</html>
EOL
