#!/usr/bin/perl

use CGI;
use open ":utf8";
use Encode;
use utf8;
use open IO=>"utf8";
use IO::File;

my $q = CGI->new();
$q->charset("utf-8");


# read (STDIN, $PostData, $ENV{'CONTENT_LENGTH'});
$PostData=decode('utf8', $q->param('kanso'));
if ($PostData ne ''){
  open(FIL,"> main.html");
  print FIL $PostData;
  close(FIL);
} else {
  open(IN,"main.html");
  @Temp=<IN>;
  $PostData=join("",@Temp);
  close(IN);
}



#ヘッダの出力のサンプル
# print "Content-type: text/html\n\n";
print $q->header(-charset => 'utf-8');



#HTMLの出力のサンプル

print <<EOL; 

<html lang="ja">
<head>
<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link type='text/css' rel='stylesheet' href='base.css' />
<title></title></head><body>


<form action="http://cgi.geocities.jp/masamatsu1970/hvhgciygrbt.cgi" method="post">
<textarea name="kanso" rows="9" cols="39">
$PostData
</textarea><br>
<input type="submit" value="送信">
</form>


</body></html>

EOL

