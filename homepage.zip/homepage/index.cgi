#!/usr/bin/perl


read (STDIN, $PostData, $ENV{'CONTENT_LENGTH'});







#ヘッダの出力のサンプル
print "Content-type: text/html\n\n";

#HTMLの出力のサンプル

print <<EOL; 

<html lang="ja">
<head>
<meta content='width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0' name='viewport'/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Content-Style-Type" content="text/css">
<meta http-equiv="Content-Script-Type" content="text/javascript">
<link type='text/css' rel='stylesheet' href='base.css' />
<title></title></head><body>


<form action="http://cgi.geocities.jp/masamatsu1970/index.cgi" method="post">
<textarea name="kanso" rows="10" cols="30">
$PostData
</textarea><br>
<input type="submit" value="送信">
</form>


</body></html>

EOL

